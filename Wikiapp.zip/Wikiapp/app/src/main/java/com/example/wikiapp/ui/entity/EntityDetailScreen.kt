package com.example.wikiapp.ui.entity

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.wikiapp.data.model.Claim
import com.example.wikiapp.data.model.WikidataEntity
import com.example.wikiapp.ui.viewmodel.EntityViewModel
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntityDetailScreen(
    entityId: String,
    onNavigateBack: () -> Unit,
    onEditClick: (String) -> Unit,
    viewModel: EntityViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    
    LaunchedEffect(entityId) {
        viewModel.loadEntity(entityId)
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Entity Details") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        // Open full page in browser/CustomTab
                        val url = "https://www.wikidata.org/wiki/$entityId"
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    }) {
                        Icon(Icons.Default.Public, contentDescription = "Open on Wikidata")
                    }
                    IconButton(onClick = {
                        // Open edit page in browser (user can login and edit)
                        val url = "https://www.wikidata.org/wiki/$entityId?action=edit"
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                }
            )
        }
    ) { paddingValues ->
        when {
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            uiState.error != null -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(
                            Icons.Default.Error,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.error
                        )
                        Text(
                            text = uiState.error ?: "Unknown error",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Button(onClick = { viewModel.loadEntity(entityId) }) {
                            Text("Retry")
                        }
                    }
                }
            }
            uiState.entity != null -> {
                EntityContent(
                    entity = uiState.entity!!,
                    modifier = Modifier.padding(paddingValues)
                )
            }
        }
    }
}

@Composable
fun EntityContent(
    entity: WikidataEntity,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            EntityHeader(entity = entity)
        }
        
        // Labels
        entity.labels?.let { labels ->
            if (labels.isNotEmpty()) {
                item {
                    SectionTitle("Labels")
                    labels.values.forEach { label ->
                        LabelItem(label = label)
                    }
                }
            }
        }
        
        // Descriptions
        entity.descriptions?.let { descriptions ->
            if (descriptions.isNotEmpty()) {
                item {
                    SectionTitle("Descriptions")
                    descriptions.values.forEach { description ->
                        DescriptionItem(description = description)
                    }
                }
            }
        }
        
        // Claims/Statements
        entity.claims?.let { claims ->
            if (claims.isNotEmpty()) {
                item {
                    SectionTitle("Claims")
                }
                claims.entries.forEach { (propertyId, claimList) ->
                    items(claimList) { claim ->
                        ClaimItem(propertyId = propertyId, claim = claim)
                    }
                }
            }
        }
    }
}

@Composable
fun EntityHeader(entity: WikidataEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = entity.labels?.values?.firstOrNull()?.value ?: entity.id,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = entity.id,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                )
            }
            
            entity.descriptions?.values?.firstOrNull()?.let { description ->
                Text(
                    text = description.value,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.9f)
                )
            }
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

@Composable
fun LabelItem(label: com.example.wikiapp.data.model.Label) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label.value,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = label.language,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun DescriptionItem(description: com.example.wikiapp.data.model.Description) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = description.value,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = description.language,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun ClaimItem(propertyId: String, claim: Claim) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = propertyId,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            
            claim.mainsnak.datavalue?.let { dataValue ->
                Text(
                    text = formatDataValue(dataValue),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            
            claim.rank?.let { rank ->
                Text(
                    text = "Rank: $rank",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
    }
}

fun formatDataValue(dataValue: com.example.wikiapp.data.model.DataValue): String {
    return when (dataValue.type) {
        "wikibase-entityid" -> {
            // Try to parse as EntityIdValue
            try {
                val value = dataValue.value as? Map<*, *>
                val id = value?.get("id") as? String ?: "Unknown"
                id
            } catch (e: Exception) {
                dataValue.value?.toString() ?: "Unknown"
            }
        }
        "string" -> {
            val value = dataValue.value as? Map<*, *>
            value?.get("value") as? String ?: dataValue.value?.toString() ?: "Unknown"
        }
        "time" -> {
            val value = dataValue.value as? Map<*, *>
            val time = value?.get("time") as? String ?: "Unknown"
            time
        }
        "quantity" -> {
            val value = dataValue.value as? Map<*, *>
            val amount = value?.get("amount") as? String ?: "Unknown"
            amount
        }
        else -> dataValue.value?.toString() ?: "Unknown"
    }
}

