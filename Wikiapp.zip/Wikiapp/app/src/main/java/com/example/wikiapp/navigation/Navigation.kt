package com.example.wikiapp.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.wikiapp.ui.entity.EntityDetailScreen
import com.example.wikiapp.ui.entity.EntityWebScreen
import com.example.wikiapp.ui.edit.EditScreen
import com.example.wikiapp.ui.home.HomeScreen
import com.example.wikiapp.ui.search.SearchScreen

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Search : Screen("search")
    object EntityDetail : Screen("entity_detail/{entityId}") {
        fun createRoute(entityId: String) = "entity_detail/$entityId"
    }
    object EntityWeb : Screen("entity_web/{entityId}") {
        fun createRoute(entityId: String) = "entity_web/$entityId"
    }
    object Edit : Screen("edit/{entityId}") {
        fun createRoute(entityId: String) = "edit/$entityId"
    }
}

@Composable
fun AppNavigation(navController: NavHostController = rememberNavController()) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                navController = navController,
                onNavigationItemClick = { route ->
                    when (route) {
                        "search" -> navController.navigate(Screen.Search.route)
                        "home" -> { /* Already on home */ }
                        else -> { /* Handle other routes */ }
                    }
                }
            )
        }
        
        composable(Screen.Search.route) {
            SearchScreen(
                onEntityClick = { entityId ->
                    navController.navigate(Screen.EntityWeb.createRoute(entityId))
                },
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
        
        composable(
            route = Screen.EntityDetail.route,
            arguments = listOf(
                navArgument("entityId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val entityId = backStackEntry.arguments?.getString("entityId") ?: ""
            EntityDetailScreen(
                entityId = entityId,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onEditClick = { id ->
                    navController.navigate(Screen.Edit.createRoute(id))
                }
            )
        }

        composable(
            route = Screen.EntityWeb.route,
            arguments = listOf(
                navArgument("entityId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val entityId = backStackEntry.arguments?.getString("entityId") ?: ""
            EntityWebScreen(
                entityId = entityId,
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable(
            route = Screen.Edit.route,
            arguments = listOf(
                navArgument("entityId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val entityId = backStackEntry.arguments?.getString("entityId") ?: ""
            EditScreen(
                entityId = entityId,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}

