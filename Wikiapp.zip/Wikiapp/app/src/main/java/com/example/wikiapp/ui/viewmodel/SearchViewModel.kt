package com.example.wikiapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wikiapp.data.model.SearchResult
import com.example.wikiapp.data.repository.WikidataRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SearchUiState(
    val query: String = "",
    val results: List<SearchResult> = emptyList(),
    val suggestions: List<SearchResult> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

class SearchViewModel(
    private val repository: WikidataRepository = WikidataRepository()
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()
    private var suggestJob: Job? = null
    
    fun updateQuery(query: String) {
        _uiState.value = _uiState.value.copy(query = query)
        // live suggestions with debounce
        suggestJob?.cancel()
        if (query.isBlank()) {
            _uiState.value = _uiState.value.copy(suggestions = emptyList())
            return
        }
        suggestJob = viewModelScope.launch {
            delay(300)
            repository.searchEntities(query, limit = 10).fold(
                onSuccess = { response ->
                    _uiState.value = _uiState.value.copy(
                        suggestions = response.search ?: emptyList()
                    )
                },
                onFailure = {
                    // keep previous suggestions
                }
            )
        }
    }
    
    fun search() {
        val query = _uiState.value.query.trim()
        if (query.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                results = emptyList(),
                error = null
            )
            return
        }
        
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoading = true,
                error = null
            )
            
            repository.searchEntities(query).fold(
                onSuccess = { response ->
                    _uiState.value = _uiState.value.copy(
                        results = response.search ?: emptyList(),
                        isLoading = false,
                        error = null
                    )
                },
                onFailure = { exception ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = exception.message ?: "Search failed. Please check your internet connection."
                    )
                }
            )
        }
    }
    
    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}

