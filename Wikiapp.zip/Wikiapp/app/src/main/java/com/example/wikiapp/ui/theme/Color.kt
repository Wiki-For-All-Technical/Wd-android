package com.example.wikiapp.ui.theme

import androidx.compose.ui.graphics.Color

// Wikimedia/Wikidata color scheme
val WikimediaBlue = Color(0xFF3366CC)
val WikimediaBlueLight = Color(0xFF5B8DD6)
val WikimediaBlueDark = Color(0xFF1E4A99)

val WikimediaGrey = Color(0xFF54595D)
val WikimediaGreyLight = Color(0xFF72777D)
val WikimediaGreyDark = Color(0xFF3A3A3A)

// Light theme colors
val LightPrimary = WikimediaBlue
val LightSecondary = WikimediaGrey
val LightTertiary = WikimediaBlueLight

// Dark theme colors
val DarkPrimary = WikimediaBlueLight
val DarkSecondary = WikimediaGreyLight
val DarkTertiary = WikimediaBlue