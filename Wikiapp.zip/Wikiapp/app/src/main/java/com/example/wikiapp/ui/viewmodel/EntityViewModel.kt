package com.example.wikiapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wikiapp.data.model.WikidataEntity
import com.example.wikiapp.data.repository.WikidataRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class EntityUiState(
    val entity: WikidataEntity? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)

class EntityViewModel(
    private val repository: WikidataRepository = WikidataRepository()
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(EntityUiState())
    val uiState: StateFlow<EntityUiState> = _uiState.asStateFlow()
    
    fun loadEntity(entityId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoading = true,
                error = null
            )
            
            repository.getEntity(entityId).fold(
                onSuccess = { entity ->
                    _uiState.value = _uiState.value.copy(
                        entity = entity,
                        isLoading = false,
                        error = null
                    )
                },
                onFailure = { exception ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = exception.message ?: "Failed to load entity"
                    )
                }
            )
        }
    }
    
    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}





